export class Todo
{
    id: number;
    name : string;
    status : string;
}