package com.cg.service;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.dao.ProductDao;
import com.cg.entities.Product;
import com.cg.exception.ApplicationException;





@Service
@Transactional
public class ProductServiceImpl implements ProductService {

	@Autowired private ProductDao dao;	
	
	@Transactional
	public void create(Product ac) {
		// TODO Auto-generated method stub
		dao.save(ac);
	}

	
	@Transactional(readOnly=true)
	public Product findById(Integer id) {
		// TODO Auto-generated method stub
		//Optional<Wallet> id=dao.findById(accno);
		//if(!id.isPresent) {
			//throw new ApplicationException("please enter the id");
		//}
		//else {
		return dao.findById(id).get();
		//}
	}

	
	
	
	@Transactional
	public List<Product> findAll() {
		// TODO Auto-generated method stub
		return dao.findAll();
	}


	@Transactional
	public void afterbuyingByID(Integer id) {
		// TODO Auto-generated method stub
		dao.deleteById(id);
		System.out.println("The record is deleted...");
		
	}


	@Transactional
	public Product isAvailability(Product productid,Product ac) {
		if (dao.existsById(ac.getProductid())) {
			throw new RuntimeException("Product is Available ...");
			
		 } else {

		  System.out.println("Sorrry No Products Found ");
			 

			 
		  //Product p1 = dao.save(ac);
		  //System.out.println("Saved " + p1.getProductName());

		// }	

	}
		return null;


	
	
	}
	
}
	 

	



	


	


