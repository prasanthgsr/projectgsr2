package com.cg.service;
import java.util.List;

import com.cg.entities.Product;

public interface ProductService 
{
	 void create(Product ac);
	 Product findById(Integer productid);
	 //void transferAccount(double amount, Product a1,Product a2);
	 //void addMoney(double amount, Product ac);
	 List<Product> findAll();
	 //void deleteByID(Integer productid);
	 Product isAvailability(Product productid,Product ac);
	 void afterbuyingByID(Integer productid);
	 //void withdraw(Double amount,Product ac);
	 //Product showBalance(Integer id);
	
	
	
}
