package com.cg.entities;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

@Entity
@Table(name="products")
@XmlRootElement
public class Product 
{
	@Id
	@Column(name="pid",length=12)
	  private int productid;
	
	
	@Column(name="pname",length=50)
	  private String productName;	
	   
	  @Column(name="price",length=10)
	  private double productprice;
	  
	  @Column(name="imageurl",length=50)
	  private String imageurl;
	  
	  @Column(name="category",length=50)
	  private String productcategory;
	  
	  @Column(name="model",length=50)
	  private String productmodel;
	  
	  @Column(name="uploaddate",length=50)
	  private Date uploaddate;
	  
	  
	  @Column(name="quantity",length=10)
	  private long productquantity;
	  
	  
	  @Column(name="description",length=50)
	  private String description;
	  
	  @Column(name="rating",length=10)
	  private int productratings;
	  
	  @Column(name="discount",length=10)
	  private int discounts;
	  
	  @Column(name="promocode",length=50)
	  private String productpromocode;
	 
	   
	  @Column(name="feedback",length=50)
	  private String productfeedback;


	public int getProductid() {
		return productid;
	}


	public void setProductid(int productid) {
		this.productid = productid;
	}


	public String getProductName() {
		return productName;
	}


	public void setProductName(String productName) {
		this.productName = productName;
	}


	public double getProductprice() {
		return productprice;
	}


	public void setProductprice(double productprice) {
		this.productprice = productprice;
	}


	public String getImageurl() {
		return imageurl;
	}


	public void setImageurl(String imageurl) {
		this.imageurl = imageurl;
	}


	public String getProductcategory() {
		return productcategory;
	}


	public void setProductcategory(String productcategory) {
		this.productcategory = productcategory;
	}


	public String getProductmodel() {
		return productmodel;
	}


	public void setProductmodel(String productmodel) {
		this.productmodel = productmodel;
	}


	public Date getUploaddate() {
		return uploaddate;
	}


	public void setUploaddate(Date uploaddate) {
		this.uploaddate = uploaddate;
	}


	public long getProductquantity() {
		return productquantity;
	}


	public void setProductquantity(long productquantity) {
		this.productquantity = productquantity;
	}


	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}


	public int getProductratings() {
		return productratings;
	}


	public void setProductratings(int productratings) {
		this.productratings = productratings;
	}


	public int getDiscounts() {
		return discounts;
	}


	public void setDiscounts(int discounts) {
		this.discounts = discounts;
	}


	public String getProductpromocode() {
		return productpromocode;
	}


	public void setProductpromocode(String productpromocode) {
		this.productpromocode = productpromocode;
	}


	public String getProductfeedback() {
		return productfeedback;
	}


	public void setProductfeedback(String productfeedback) {
		this.productfeedback = productfeedback;
	}
	  
	  
	  
	  
	  
	  
	  
	  
	  
	   
	  
}