package com.cg.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entities.Product;
import com.cg.service.ProductService;




@RestController
@RequestMapping("/product")

public class ProductController 
{
	 @Autowired private ProductService service;
	 @PostMapping(value="/create",consumes= {"application/xml","application/json"})
	 public ResponseEntity<String> insert(@RequestBody Product ac)
	 {
	 System.out.println("Creating an Product");
	 service.create(ac);
	 return new ResponseEntity<String>("Record created....",HttpStatus.CREATED);
	 }
	 
	 @GetMapping("/find")
	 public Product find(@RequestParam("id") Integer id) 
	 {
	 System.out.println("Search Product by id "+id);
	 Product ac = service.findById(id);
	 return ac;
	 }
	 
	 @GetMapping("/findall")
	 public List<Product> findAll() 
	 {
	 List<Product> ac = service.findAll();
	 return ac;
	 }
	 
	 @GetMapping("/isavailability")
	 public Product isAvailability(@RequestParam("productid") Integer productid) 
	 {
	 System.out.println("Search Product by id "+productid);
	 Product ac = service.findById(productid);
	 return ac;
		 
	 }
	 
	
	 
	 @DeleteMapping("/afterbuy")
	 public ResponseEntity<String> afterbuyingByID(@RequestParam("productid") Integer productid) 
	 {
	 service.afterbuyingByID(productid);
	 return new ResponseEntity<String>("Product is Buyed...!",HttpStatus.OK);
	 }
	 
	 
}
