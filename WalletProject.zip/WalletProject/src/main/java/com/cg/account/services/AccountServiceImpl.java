package com.cg.account.services;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.account.dao.AccountDao;
import com.cg.account.entities.Account;

@Service
public class AccountServiceImpl implements AccountService {

	@Autowired private AccountDao dao;

	@Transactional
	public void create(Account ac) {
		// TODO Auto-generated method stub
     dao.save(ac);
	}

	@Transactional
	public Account search(String mobileno) {
		// TODO Auto-generated method stub
		return dao.findById(mobileno).get();
	}
	@Transactional
	public void delete(String mobileno) {
		// TODO Auto-generated method stub
        dao.deleteById(mobileno);
	}

	@Transactional
	public Account addMoney(String mobileno, double amount) {
		// TODO Auto-generated method stub
     Account record=search(mobileno);
        Double newbal=record.getBalance()+amount;
        record.setBalance(newbal);
		return dao.save(record);
	}

	@Transactional
	public String transferMoney(String mobileno1, String mobileno2, double amount) {
		// TODO Auto-generated method stub
		String ok="transfered sucessfully";
		Account record1=search(mobileno1);
		Account record2=search(mobileno2);
		double bal1=record1.getBalance()-amount;
		double bal2=record2.getBalance()+amount;
		record1.setBalance(bal1);
		record1.setBalance(bal2);
		dao.save(record1);
		dao.save(record2);
		
		return ok;
	}

	@Transactional
	public Account WithDraw(String mobileno, double amount) {
		// TODO Auto-generated method stub
		 Account record=search(mobileno);
	        Double newbal=record.getBalance()-amount;
	        record.setBalance(newbal);
			return dao.save(record);
	
	}

	@Transactional
	public List<Account> getAllAccount() {
		// TODO Auto-generated method stub
		
		return dao.findAll();
	}
	

}
